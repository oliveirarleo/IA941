#!/bin/bash

java -jar "WorldServer3D.jar"&
sleep 3
java -jar "KeyboardMind.jar"&


