java -jar ws3d/WorldServer3D.jar &
sleep 5
java -jar jSoar/DemoJSOAR.jar